/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.productossoftware;

abstract class ProductoSoftware {
    protected String nombre;
    protected double precio;
    
    public ProductoSoftware(String nombre, double precio) {
        this.nombre = nombre;
        this.precio = precio;
    }
    
    public abstract void ejecutar();
    public abstract void actualizar();
    
    public void mostrarInfo() {
        System.out.println("Nombre: " + nombre);
        System.out.println("Precio: $" + precio);
    }
}

// Clases concretas que heredan de ProductoSoftware
class SistemaOperativo extends ProductoSoftware {
    private String version;
    
    public SistemaOperativo(String nombre, double precio, String version) {
        super(nombre, precio);
        this.version = version;
    }
    
    @Override
    public void ejecutar() {
        System.out.println("Iniciando sistema operativo " + nombre + " version " + version);
    }
    
    @Override
    public void actualizar() {
        System.out.println("Actualizando a la nueva version de " + nombre);
    }
}

class AplicacionMovil extends ProductoSoftware {
    private String plataforma;
    
    public AplicacionMovil(String nombre, double precio, String plataforma) {
        super(nombre, precio);
        this.plataforma = plataforma;
    }
    
    @Override
    public void ejecutar() {
        System.out.println("Lanzando aplicacion " + nombre + " en " + plataforma);
    }
    
    @Override
    public void actualizar() {
        System.out.println("Instalando nueva version de " + nombre);
    }
}

public class ProductosSoftware {

    public static void main(String[] args) {
        // Array de objetos ProductosSoftware 
        ProductoSoftware[] productos = new ProductoSoftware[2];
        productos[0] = new SistemaOperativo("Windows 11", 199.99, "22H2");
        productos[1] = new AplicacionMovil("Instagram", 0, "Android");
        
        // Iteramos y llamamos a los métodos polimórficos
        for (ProductoSoftware producto : productos) {
            producto.mostrarInfo();
            producto.ejecutar();
            producto.actualizar();
            System.out.println("------------------------");
        }
    }
}
