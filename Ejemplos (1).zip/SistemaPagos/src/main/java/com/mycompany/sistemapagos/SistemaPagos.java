/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.sistemapagos;

abstract class MetodoPago {
    protected String tipo;
    protected double comision;
    
    public MetodoPago(String tipo, double comision) {
        this.tipo = tipo;
        this.comision = comision;
    }
    
    public abstract boolean procesarPago(double monto);
    public abstract void emitirComprobante(String idTransaccion);
    
    public double calcularComision(double monto) {
        return monto * (comision / 100);
    }
    
    public void mostrarInfo() {
        System.out.println("Metodo de pago: " + tipo);
        System.out.println("Comision: " + comision + "%");
    }
}

class TarjetaCredito extends MetodoPago {
    private String numero;
    private String banco;
    
    public TarjetaCredito(String numero, String banco, double comision) {
        super("Tarjeta de Credito", comision);
        this.numero = numero;
        this.banco = banco;
    }
    
    @Override
    public boolean procesarPago(double monto) {
        System.out.println("Procesando pago con tarjeta de credito...");
        System.out.println("Numero: " + numero.substring(0, 4) + "****" + numero.substring(12));
        System.out.println("Banco: " + banco);
        System.out.println("Monto: $" + monto);
        double comisionTotal = calcularComision(monto);
        System.out.println("Comision: $" + comisionTotal);
        return true;
    }
    
    @Override
    public void emitirComprobante(String idTransaccion) {
        System.out.println("Emitiendo comprobante para transaccion: " + idTransaccion);
        System.out.println("Metodo: Tarjeta de Credito");
        System.out.println("Banco: " + banco);
    }
}

class PayPal extends MetodoPago {
    private String email;
    
    public PayPal(String email, double comision) {
        super("PayPal", comision);
        this.email = email;
    }
    
    @Override
    public boolean procesarPago(double monto) {
        System.out.println("Procesando pago con PayPal...");
        System.out.println("Email: " + email);
        System.out.println("Monto: $" + monto);
        double comisionTotal = calcularComision(monto);
        System.out.println("Comision: $" + comisionTotal);
        return true;
    }
    
    @Override
    public void emitirComprobante(String idTransaccion) {
        System.out.println("Emitiendo comprobante para transaccion: " + idTransaccion);
        System.out.println("Metodo: PayPal");
        System.out.println("Email: " + email);
    }
}

public class SistemaPagos {

    public static void main(String[] args) {
        MetodoPago[] metodosPago = new MetodoPago[2];
        metodosPago[0] = new TarjetaCredito("2537564897103486", "Pichincha", 3.5);
        metodosPago[1] = new PayPal("usuario@example.com", 2.9);
        
        double montoPago = 1000.0;
        String idTransaccion = "TX" + System.currentTimeMillis();
        
        for (MetodoPago metodo : metodosPago) {
            metodo.mostrarInfo();
            boolean exitoso = metodo.procesarPago(montoPago);
            
            if (exitoso) {
                metodo.emitirComprobante(idTransaccion);
            } else {
                System.out.println("Error en el pago");
            }
            System.out.println("------------------------");
        }
    }
}
