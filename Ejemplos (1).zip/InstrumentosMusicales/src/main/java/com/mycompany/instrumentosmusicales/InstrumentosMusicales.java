/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.instrumentosmusicales;

abstract class InstrumentoMusical {
    protected String nombre;
    protected String tipo;
    
    public InstrumentoMusical(String nombre, String tipo) {
        this.nombre = nombre;
        this.tipo = tipo;
    }
    
    public abstract void tocar();
    public abstract void afinar();
    
    public void mostrarInfo() {
        System.out.println("Instrumento: " + nombre);
        System.out.println("Tipo: " + tipo);
    }
}

class Guitarra extends InstrumentoMusical {
    private int numCuerdas;
    
    public Guitarra(String nombre, int numCuerdas) {
        super(nombre, "Cuerda");
        this.numCuerdas = numCuerdas;
    }
    
    @Override
    public void tocar() {
        System.out.println("Tocando acordes en la guitarra " + nombre);
    }
    
    @Override
    public void afinar() {
        System.out.println("Afinando las " + numCuerdas + " cuerdas de la guitarra");
    }
}

class Piano extends InstrumentoMusical {
    private int numTeclas;
    
    public Piano(String nombre, int numTeclas) {
        super(nombre, "Teclado");
        this.numTeclas = numTeclas;
    }
    
    @Override
    public void tocar() {
        System.out.println("Tocando melodia en el piano " + nombre);
    }
    
    @Override
    public void afinar() {
        System.out.println("Afinando las " + numTeclas + " teclas del piano");
    }
}

public class InstrumentosMusicales {

    public static void main(String[] args) {
        InstrumentoMusical[] instrumentos = new InstrumentoMusical[2];
        instrumentos[0] = new Guitarra("Fender Stratocaster", 6);
        instrumentos[1] = new Piano("Yamaha Grand", 88);
        
        for (InstrumentoMusical instrumento : instrumentos) {
            instrumento.mostrarInfo();
            instrumento.tocar();
            instrumento.afinar();
            System.out.println("------------------------");
        }
    }
}
