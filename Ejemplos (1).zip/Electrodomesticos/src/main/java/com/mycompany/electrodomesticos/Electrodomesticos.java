/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.electrodomesticos;

abstract class Electrodomestico {
    protected String marca;
    protected double precio;
    protected double consumoEnergetico;
    
    public Electrodomestico(String marca, double precio, double consumoEnergetico) {
        this.marca = marca;
        this.precio = precio;
        this.consumoEnergetico = consumoEnergetico;
    }
    
    public abstract void encender();
    public abstract void apagar();
    
    public void mostrarInfo() {
        System.out.println("Marca: " + marca);
        System.out.println("Precio: $" + precio);
        System.out.println("Consumo energetico: " + consumoEnergetico + " kWh");
    }
}

class Refrigerador extends Electrodomestico {
    private int temperatura;
    
    public Refrigerador(String marca, double precio, double consumoEnergetico, int temperatura) {
        super(marca, precio, consumoEnergetico);
        this.temperatura = temperatura;
    }
    
    @Override
    public void encender() {
        System.out.println("Encendiendo refrigerador " + marca);
        System.out.println("Ajustando temperatura a " + temperatura + "°C");
    }
    
    @Override
    public void apagar() {
        System.out.println("Apagando refrigerador " + marca);
    }
    
    public void ajustarTemperatura(int nuevaTemp) {
        this.temperatura = nuevaTemp;
        System.out.println("Temperatura ajustada a " + temperatura + "°C");
    }
}

class Lavadora extends Electrodomestico {
    private int capacidad;
    
    public Lavadora(String marca, double precio, double consumoEnergetico, int capacidad) {
        super(marca, precio, consumoEnergetico);
        this.capacidad = capacidad;
    }
    
    @Override
    public void encender() {
        System.out.println("Encendiendo lavadora " + marca);
        System.out.println("Capacidad: " + capacidad + " kg");
    }
    
    @Override
    public void apagar() {
        System.out.println("Apagando lavadora " + marca);
    }
    
    public void iniciarCiclo(String tipo) {
        System.out.println("Iniciando ciclo de lavado: " + tipo);
    }
}

public class Electrodomesticos {

    public static void main(String[] args) {
        Electrodomestico[] electrodomesticos = new Electrodomestico[2];
        electrodomesticos[0] = new Refrigerador("Samsung", 899.99, 45.5, 4);
        electrodomesticos[1] = new Lavadora("LG", 649.99, 30.2, 8);
        
        for (Electrodomestico electrodomestico : electrodomesticos) {
            electrodomestico.mostrarInfo();
            electrodomestico.encender();
            electrodomestico.apagar();
            System.out.println("------------------------");
        }
        
        // Uso específico de cada clase
        Refrigerador refri = (Refrigerador) electrodomesticos[0];
        refri.ajustarTemperatura(2);
        
        Lavadora lavadora = (Lavadora) electrodomesticos[1];
        lavadora.iniciarCiclo("Ropa delicada");
    }
}
