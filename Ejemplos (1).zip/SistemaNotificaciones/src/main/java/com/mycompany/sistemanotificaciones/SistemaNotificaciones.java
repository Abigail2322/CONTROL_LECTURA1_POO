/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.sistemanotificaciones;

abstract class Notificacion {
    protected String remitente;
    protected String destinatario;
    protected String mensaje;
    
    public Notificacion(String remitente, String destinatario, String mensaje) {
        this.remitente = remitente;
        this.destinatario = destinatario;
        this.mensaje = mensaje;
    }
    
    public abstract boolean enviar();
    public abstract void registrarEnvio();
    
    public void mostrarInfo() {
        System.out.println("De: " + remitente);
        System.out.println("Para: " + destinatario);
        System.out.println("Mensaje: " + mensaje);
    }
}

class NotificacionEmail extends Notificacion {
    private String asunto;
    
    public NotificacionEmail(String remitente, String destinatario, String mensaje, String asunto) {
        super(remitente, destinatario, mensaje);
        this.asunto = asunto;
    }
    
    @Override
    public boolean enviar() {
        System.out.println("Enviando email...");
        System.out.println("Asunto: " + asunto);
        mostrarInfo();
        return true;
    }
    
    @Override
    public void registrarEnvio() {
        System.out.println("Registrando envio de email en el sistema");
        System.out.println("Fecha: " + java.time.LocalDateTime.now());
    }
}

class NotificacionSMS extends Notificacion {
    private String operador;
    
    public NotificacionSMS(String remitente, String destinatario, String mensaje, String operador) {
        super(remitente, destinatario, mensaje);
        this.operador = operador;
    }
    
    @Override
    public boolean enviar() {
        System.out.println("Enviando SMS a traves de " + operador + "...");
        mostrarInfo();
        return true;
    }
    
    @Override
    public void registrarEnvio() {
        System.out.println("Registrando envio de SMS en el sistema");
        System.out.println("Fecha: " + java.time.LocalDateTime.now());
    }
}

public class SistemaNotificaciones {

    public static void main(String[] args) {
        Notificacion[] notificaciones = new Notificacion[2];
        notificaciones[0] = new NotificacionEmail("info@empresa.com", "cliente@gmail.com", 
                                                  "Su pedido ha sido confirmado", "Confirmacion de pedido");
        notificaciones[1] = new NotificacionSMS("+123456789", "+987654321", 
                                              "Su codigo de verificacion es: 215783", "Movistar");
        
        for (Notificacion notificacion : notificaciones) {
            boolean exitoso = notificacion.enviar();
            
            if (exitoso) {
                notificacion.registrarEnvio();
            } else {
                System.out.println("Error al enviar la notificacion");
            }
            System.out.println("------------------------");
        }
    }
}
